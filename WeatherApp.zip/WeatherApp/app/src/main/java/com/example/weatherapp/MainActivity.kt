package com.example.weatherapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val startbutton: Button = findViewById(R.id.button1)
        val exitbutton: Button = findViewById(R.id.button2)
        startbutton.setOnClickListener {

            val intent1 = Intent(this,MainActivity2::class.java)
            startActivity(intent1)
        }

        exitbutton.setOnClickListener {
            exitProcess(0)
        }
    }
}