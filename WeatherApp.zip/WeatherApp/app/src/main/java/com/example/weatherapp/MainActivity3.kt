package com.example.weatherapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val DetailedWeather: TextView = findViewById(R.id.textView11)
        val Back: Button = findViewById(R.id.button11)

        // Get the weekly temperatures from the intent
        val weeklyTemperatures = intent.getIntArrayExtra("weeklyTemperatures")

        // Display detailed weather data
        val detailedWeatherData = weeklyTemperatures?.mapIndexed { index, temperature ->
            "Day ${index + 1}: $temperature°C"
        }?.joinToString("\n")

        DetailedWeather.text = "Detailed Weather Data:\n$detailedWeatherData"

        Back.setOnClickListener {
            finish()
        }
    }
}