package com.example.weatherapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {

    private val weeklyTemperatures = arrayOf(20, 22, 18, 25, 19, 21, 23)
    private var averageTemperature = 0.0

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val WeeklyWeather: TextView = findViewById(R.id.textview1)
        val AverageTemperature: TextView = findViewById(R.id.textview2)
        val btnDetails: Button = findViewById(R.id.button1)
        val btnClearData: Button = findViewById(R.id.button2)
        val btnExit: Button = findViewById(R.id.button3)
        val btnPrev: Button = findViewById(R.id.button4)

        // Display weekly temperatures
        WeeklyWeather.text = "Weekly Temperatures: ${weeklyTemperatures.joinToString(", ")}"

        // Calculate average temperature
        averageTemperature = weeklyTemperatures.average()
        AverageTemperature.text = "Average Temperature: $averageTemperature°C"

        btnDetails.setOnClickListener {
            val intent = Intent(this, MainActivity3::class.java)
            intent.putExtra("weeklyTemperatures", weeklyTemperatures)
            startActivity(intent)
        }

        btnClearData.setOnClickListener {
            // Clear and re-enter data logic can be implemented here
            WeeklyWeather.text = "Weekly Temperatures: "
            AverageTemperature.text = "Average Temperature: "
        }

        btnExit.setOnClickListener {
            finishAffinity() // Exits the app
        }

        btnPrev.setOnClickListener {
            finish()
        }
    }
}